OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> f = fiberator()\n>>> assert next(f) == 0\n>>> assert next(f) == 1\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> f = fiberator()\n'
                                               '>>> assert next(f) == 0\n'
                                               '>>> assert next(f) == 1\n'
                                               '>>> assert next(f) == 1\n'
                                               '>>> assert next(f) == 2\n'
                                               '>>> assert next(f) == 3\n'
                                               '>>> assert next(f) == 5\n'
                                               '>>> assert next(f) == 8\n'
                                               '>>> assert next(f) == 13\n'
                                               '>>> assert next(f) == 21\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
